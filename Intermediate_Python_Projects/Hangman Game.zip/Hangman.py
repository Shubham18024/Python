import random
import hangman_art as art
import hangman_words as words
print(art.logo)

choosen_word = random.choices(words.word_list)[0]

placeholder = ""
for i in choosen_word:
    placeholder+="_ "
print(f"Word to guess : {placeholder}\n")

game_over = False
correct_letter = []
lives = 6

while not game_over :
    print(f"**********************{lives} LIVES LEFT!*************************")
    guess = input("Guess the word : ").lower()

    if guess in correct_letter:
        print(f"You've already guessed {guess}")
        
    display = ""
    
    for i in choosen_word :
        if guess == i:
            display+=guess
            correct_letter.append(guess)
        elif i in correct_letter:
            display +=i
        else:
            display+="_"
    print(display)

    
    if guess not in choosen_word:
        lives-=1
        if lives == 0:
            game_over = True
            print(f"***************IT WAS {choosen_word},You Lose!****************") 
    
    if "_" not in display :
        game_over = True
        print("**************You Win!**************")

    print(art.stages[lives])